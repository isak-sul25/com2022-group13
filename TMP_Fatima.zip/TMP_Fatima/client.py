
from ast import Break
import random
import socket
import time
import zlib
import os


serverAddressPort = ("127.0.0.1", 1400)
MAX = 576
status = "notconnected"

SYN = '100'
ACK = 'OK'


#setting time out
socket.setdefaulttimeout(10)
# Create a UDP socket at client side
clientSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#print("client is connected" )
Input =''
seq_num_c = 0
ack_num_c = ''
acknowledged = 0
Ack_packets = []
Nack_packets = []
NACK = 'Response not acknowldged, Client must send a request again'
cash = {}
keys = []
keys = cash.keys 
cashed = ''


    #send SYN packet
syn_cs = ',' + '\n' + SYN
syn_cs = str(zlib.crc32(syn_cs.encode('utf8')))
sync = syn_cs + "," + "\n" + SYN
clientSock.sendto(sync.encode('utf-8'), serverAddressPort)


    #receive SYN_ACK packet
syn_ack, addr = clientSock.recvfrom(MAX)
syn_ack = syn_ack.decode('utf-8')


cs  = syn_ack.split(',')[0]
m = syn_ack.split('\n')[1]
n_cs = ',' + '\n' + m
new_cs = str(zlib.crc32(n_cs.encode('utf-8')))

if(cs == new_cs):
    print("Connection Accepted")
    if (m == '100:OK'):
        status = 'connencetd'
     #send ack back
        ack_cs = ','+'\n'+ACK
        ack_cs = str(zlib.crc32(ack_cs.encode('utf-8')))
        ackn = ack_cs + "," + "\n" + ACK
        clientSock.sendto(ackn.encode('utf-8'), serverAddressPort)
        print("client is connected")
# Send to server using created UDP socket
print("ENTER 'MENUS' TO VIEW ALL AVAILABLE MENUS"+  "\n" +  "ENTER 'MENU TODAY' TO VIEW THE MENU OF THE DAY"+  "\n" +  "ENTER 'MENU <MENU NAME>' TO VIEW MENU <NAME>" +"\n" + "ENTER 'EXIT' TO QUIT USER INPUT" )


while (Input != 'EXIT'):
    try:
        rand = random.randint(0, 10)

        #clients enters input
        #checksum of input is computed
        #final request =checksum + , + optional field +  input
        #request encoded 
        Input = input('client:')
        if(Input == 'EXIT'):
            clientSock.close
            continue

        #cashing
        Input_array = Input.split()
        for x in Input_array:
            #keys = cash.keys
            if(x in cash):
                cashed_menu = cash.get(x)
                response = 'Menu already requested before: {}'.format(cashed_menu)
                print(response)
                cashed = 'done'
            break
        if(cashed == 'done'):
            continue
        
        
        if(seq_num_c == 0):
            optional = str(seq_num_c)
        else:
            optional =  ack_num_c + ":" + str(seq_num_c) #...
        packet = ',' + optional  + ';' + '\n' + Input
        c_checksum = str(zlib.crc32(packet.encode('utf-8')))
        request = c_checksum + packet
        bytesToSend = request.encode('utf-8')
        
        #get current time for RTT computation
        cur_time=time.time() *1000
        #request sent from client to server
        if(len(bytesToSend)>576):
                print('PACKET TOO LARGE')
        else:
            clientSock.sendto(bytesToSend, serverAddressPort)
            
        #receive response 
        #if rand < 2:
            #print("response timing out, send request again")
            #continue 
        packetFromServer, address = clientSock.recvfrom(MAX)
        packetFromServer = packetFromServer.decode('utf-8')
        print(packetFromServer)
        s_checksum = packetFromServer.split(',')[0]
        cs_opt = packetFromServer.split(';')[0]
        opt = cs_opt.split(',')[1]
        acknowledged = opt.split(":")[0]
        ack_num_c = opt.split(":")[1]
        msg = packetFromServer.split("\n", 1)[1]
        #to_check = ',' + packetFromServer.split(',')[1]
        to_check = ',' + opt + ';' +'\n'  + msg
        checksum_c = str(zlib.crc32(to_check.encode('utf-8')))

        if(s_checksum == checksum_c):
            print("PACKET VALID")
            ###
            #Acknowledgement 
            acknowledgement = "request " + acknowledged + " acknowledged "
            response = 'Server: {}'.format(msg)
            print(acknowledgement)
            Ack_packets.append(acknowledged)
            #time.sleep(3)
            print(response)
            print ('received after {} ms'.format((time.time() *1000)-cur_time))
            seq_num_c = seq_num_c + 1
            cash[Input] = msg
        else:
            print('PACKET NOT VALID')

    except socket.timeout as inst: 
        print('Request timed out, please send your request again')
print ('closing socket')
#clientSock.close