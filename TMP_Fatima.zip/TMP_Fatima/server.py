import random
import socket
import os
from datetime import date
import calendar
import time
import zlib

IP = "127.0.0.1"
Port = 1400
MAX = 576  #bandwidth ... to be changed to 576 :check ibm article

#setting time out
socket.setdefaulttimeout(30)

#menu options: Day_menu // Type_menu
menus = "This is a list of menus we offer in our restaurant:" + "Menu of the day - French menu - Mediterranean"
menu1 = "This is the menu you asked for"+ " - " +"Starter: Onion Soup" + " - "+ "Main dish: Duck Meat" +" - " +"Dessert: Creme Brulee" + " - " + 'Drink: Red Wine' 
menu2 = "This is the menu you asked for"+ " - "+"Starter: baba ganoush" +" - " + "Main dish: kabab" + " - " +"Dessert: baklava" + " - " + 'Drink: Atay' 
error = "Sorry, i don't understand your request"
Monday_menu = "This is Monday's menu you asked for"+ " - "+"Starter: Salad" + " - " + "Main dish: Pasta" + " - " +"Dessert: Waffle" + " - " + 'Drink: Tango' 
Tuesday_menu = "This is Tuesday's menu you asked for"+ " - "+"Starter: Spring Rolls" + " - " + "Main dish: Rice" + " - " +"Dessert: Cake" + " - " + 'Drink: Fanta' 
Wednesday_menu = "This is Wednesday's menu you asked for"+ " - "+"Starter: Tomato soup" + " - " + "Main dish:Tuna toast" + " - " +"Dessert: Ice Cream" + " - " + 'Drink: Coca-Cola' 
Thursday_menu = "This is Thursday's menu you asked for"+ " - "+"Starter: Salad" + " - " + "Main dish: Lasagne" + " - " +"Dessert: Waffle" + " - " + 'Drink: Tango' 
Friday_menu = "This is Fridays's menu you asked for"+ " - "+"Starter: Better dough balls" + " - " + "Main dish: Pizza" + " - " +"Dessert: Waffle" + " - " + 'Drink: Fanta' 
Saturday_menu = "No special menu of the day on Satundays"
Sunday_menu = "No special menu of the day on Sundays"
curr_date = date.today()
today = calendar.day_name[curr_date.weekday()]
data =''
seq_num_s = 0
ack_num_s = ''
acknowledged = ''
Ack_packets = []
ACK = "ACK for Packet Number:"
NACK = "Request timed out, enter a new request"
i = 0
r = 0

SYN_ACK = '100:OK'
connected_clients = []
start = 'False'
synack_sent = 'notsent'

large_packet = 'Lorem ipsum dolor sit amet. Qui architecto quia sed voluptatem debitis in dolorum repellendus sed galisum illo ex galisum harum quo architecto ducimus? Sed corporis laudantium aut expedita veritatis et dolor tempora ut similique laudantium ad debitis necessitatibus sit nisi quae et laudantium Quis. Hic velit possimus vel veniam suscipit debitis nisi ea molestias distinctio non velit eaque sit porro.Ex autem molestiae hic magni deleniti est eligendi obcaecati aut tempora ducimus sit exercitationem enim. Hic necessitatibus accusantium 33 omnis repudiandae vel vitae fugit aut voluptas totam. Ut dolores reiciendis et eveniet dolor qui internos aliquam non praesentium harum recusandae provident aut nihil quam? Nam ipsum modi rem quia aperiam ab nisi voluptas ad possimus quisquam?'







# Create Datagram socket
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind adress and IP
serverSocket.bind((IP, Port))




#three way handshake

#receive syn packet
syn_packet, addr = serverSocket.recvfrom(MAX)
syn_packet = syn_packet.decode('utf-8')


cs1  = syn_packet.split(',')[0]
m = syn_packet.split('\n')[1]
n_cs = ',' + '\n' + m
new_cs1 = str(zlib.crc32(n_cs.encode('utf-8')))
print("client  with address {} wants to connect to your this server".format(addr))
time.sleep(2)
#send syn ack packet
if (new_cs1 == cs1):

    if(m == '100'):
        synack_cs = ','+'\n'+ SYN_ACK
        synack_cs = str(zlib.crc32(synack_cs.encode('utf-8')))
        sa = synack_cs + "," + "\n" + SYN_ACK
        serverSocket.sendto(sa.encode('utf-8'), addr)
        connected_clients.append(str(addr))
        synack_sent = 'sent'
else:
    print("Request for connction failed")


if(synack_sent == 'sent'):
    ack_packet, addr = serverSocket.recvfrom(MAX)
    ack_packet = ack_packet.decode('utf-8')

    cs2  = ack_packet.split(',')[0]
    m2 = ack_packet.split('\n')[1]
    n_cs2 = ',' + '\n' + m2
    new_cs2 = str(zlib.crc32(n_cs2.encode('utf-8')))

    if(new_cs2 == cs2):
        if(m2 == 'OK'):
            start = 'True'
            connected_clients.append(str(addr))
            print("Server is up and listening")
            print("Server: Which menu would you like to check?")

#Listen for incoming datagrams
while(r < 3):
    try:
        #generate a random number from -- this is used later to simulate packet loss
        rand = random.randint(0, 10)
        #recieve the client packet along with the address it's coming from
        packetFromClient, address = serverSocket.recvfrom(MAX)
        packetFromClient = packetFromClient.decode('utf-8')
        
        r = 0

        if(i == 0):
            c_checksum = packetFromClient.split(',')[0]
            cs_optional = packetFromClient.split(';')[0]
            optional = cs_optional.split(',')[1]
            ack_num_s = optional
            message = packetFromClient.split("\n")[1]
            to_check = ',' + packetFromClient.split(',')[1]
            s_checksum = str(zlib.crc32(to_check.encode('utf-8')))
            clientAddress_message = "From client with IP address {}: {}".format(address, message)
            print(clientAddress_message)
        elif (i > 0):
            c_checksum = packetFromClient.split(',')[0]
            cs_optional = packetFromClient.split(';')[0]
            optional = cs_optional.split(',')[1]
            acknowledged = optional.split(":")[0] #....
            ack_num_s = optional.split(":")[1]
            acknowledgement = "response "+ acknowledged +" to client with address " + str(address) + " acknowledged "  #...
            print(acknowledgement) #...
            Ack_packets.append(acknowledged) #...
            #time.sleep(3) #...
            message = packetFromClient.split("\n")[1]
            to_check = ',' + packetFromClient.split(',')[1]
            s_checksum = str(zlib.crc32(to_check.encode('utf-8')))
            # for error checking in case of message corruption
            s_checksum = 0000
            clientAddress_message = "From client with IP address {}: {}".format(address, message)
            print(clientAddress_message)
            
            
            
            

        
        # sending a response to the client
        
        if c_checksum == s_checksum:
            print("PACKET VALID")
            #if rand is less than 2 we pretend to loose the packet
            if rand < 2:
                print(str(message)+" timing out, request is being retransmitted")
                continue 
            
            #else we check the client input and return menu according to requested data  
            if("MENUS" in message):
                data = menus
            
            elif("FRENCH" in message):
                data = menu1
            
            elif("MEDITERRANEAN" in message):
                data = menu2
            
            elif ("TODAY" in message):
                if today == 'Saturday':
                    data = Saturday_menu
                
                elif today == 'Sunday':
                    data = Sunday_menu
                
                elif today == 'Monday':
                    data = Monday_menu
                
                elif today == 'Tuesday':
                    data = Tuesday_menu
                
                elif today == 'Wednesday':
                    data = Wednesday_menu
                
                elif today == 'Thursday':
                    data = Thursday_menu
                    
                elif today == 'Friday':
                    data = Friday_menu
            elif('large packet' in message):
                data = large_packet
            

            else:
                data = error

            
                

           
            opt = ack_num_s + ":" + str(seq_num_s)
            packet = ','+ opt + ';' + os.linesep + data
            checksum_s = str(zlib.crc32(packet.encode('utf-8')))
            response = checksum_s + packet
            bytesToSend = response.encode('utf-8')
            if(len(bytesToSend)>576):
                print('PACKET TOO LARGE')
            else:
                serverSocket.sendto(bytesToSend, address)
                seq_num_s = seq_num_s + 1
                i = i + 1
        else:
            print("PACKET NOT VALID")
        
            
            
    except socket.timeout as inst: 
        print(NACK)
        r = r + 1
   # elif(c_checksum != s_checksum):
     #print("message not recieved")
print ('client no longer connected')
serverSocket.close
    
        

    
       
        

        
